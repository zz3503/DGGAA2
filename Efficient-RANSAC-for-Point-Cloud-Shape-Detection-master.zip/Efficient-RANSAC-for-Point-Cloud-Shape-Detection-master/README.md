# Efficient-RANSAC-for-Point-Cloud-Shape-Detection
Please note that this software is not my own work, this repository is just to try a Linux build of the original software.

As you can see in the [ReadMe.txt](ReadMe.txt) this software is written by Ruwen Schnabel and Roland Wahl:

    Copyright 2009 Ruwen Schnabel (schnabel@cs.uni-bonn.de),
                   Roland Wahl (wahl@cs.uni-bonn.de).

    This software may be used for research purposes only.


I downloaded it from https://cg.cs.uni-bonn.de/aigaion2root/attachments/Software%20v1.1.zip and it accompains the following paper:

Ruwen Schnabel, Roland Wahl, and Reinhard Klein
"Efficient RANSAC for Point-Cloud Shape Detection"
*In: Computer Graphics Forum (June 2007), 26:2(214-226)*
http://cg.cs.uni-bonn.de/en/publications/paper-details/schnabel-2007-efficient/
 
