#ifndef GfxTL_NULLCLASS_HEADER__
#define GfxTL_NULLCLASS_HEADER__

namespace GfxTL
{
	class NullClass
	{};
};

#endif
