﻿#pragma once
#include <iostream>
#include "python_pcl.h"


int main() {
    const double pts[] = { 0,0,0, 0.01,0,0, 1,1,1, 1.01,1,1 }; // 4 个点
    int labels[4];
    int nClus = RegionGrowing(pts, 4, labels);
    std::cout << "clusters: " << nClus << "\nlabels: ";
    for (int i = 0; i < 4; ++i) std::cout << labels[i] << " ";
}