#include "python_pcl.h"
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/search/kdtree.h>
#include <pcl/segmentation/extract_clusters.h>
#include <vector>
#include <pcl/features/normal_3d.h>
#include <pcl/segmentation/region_growing.h>

int DBSCAN(const double* points,size_t npoints,int* result,double tolerance,int minPts)
{
    if (!points || !result || npoints == 0) return -1;

    // 1. ���� pcl::PointCloud<pcl::PointXYZ>
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
    cloud->resize(npoints);
    for (size_t i = 0; i < npoints; ++i) {
        cloud->points[i].x = static_cast<float>(points[i * 3 + 0]);
        cloud->points[i].y = static_cast<float>(points[i * 3 + 1]);
        cloud->points[i].z = static_cast<float>(points[i * 3 + 2]);
    }

    // 2. KD-Tree
    pcl::search::KdTree<pcl::PointXYZ>::Ptr tree(new pcl::search::KdTree<pcl::PointXYZ>);
    tree->setInputCloud(cloud);

    // 3. ŷʽ���ࣨ�� DBSCAN��
    std::vector<pcl::PointIndices> cluster_indices;
    pcl::EuclideanClusterExtraction<pcl::PointXYZ> ec;
    ec.setClusterTolerance(tolerance);
    ec.setMinClusterSize(minPts);
    ec.setMaxClusterSize(std::numeric_limits<int>::max());
    ec.setSearchMethod(tree);
    ec.setInputCloud(cloud);
    ec.extract(cluster_indices);

    // 4. д�� result ����
    std::fill(result, result + npoints, 0);          // 0 Ĭ�ϵ�������
    int label = 1;
    for (const auto& indices : cluster_indices) {
        for (int idx : indices.indices) result[idx] = label;
        ++label;
    }
    return static_cast<int>(cluster_indices.size()); // ���ش���
}


int RegionGrowing(const double* points,size_t npoints,int* result)
{
    if (!points || !result || npoints == 0) return -1;

    // 1. �������� -> pcl::PointCloud
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
    cloud->resize(npoints);
    for (size_t i = 0; i < npoints; ++i) {
        cloud->points[i].x = static_cast<float>(points[i * 3 + 0]);
        cloud->points[i].y = static_cast<float>(points[i * 3 + 1]);
        cloud->points[i].z = static_cast<float>(points[i * 3 + 2]);
    }

    // 2. ���Ʒ���
    pcl::search::Search<pcl::PointXYZ>::Ptr tree(
        new pcl::search::KdTree<pcl::PointXYZ>);
    pcl::PointCloud<pcl::Normal>::Ptr normals(new pcl::PointCloud<pcl::Normal>);
    pcl::NormalEstimation<pcl::PointXYZ, pcl::Normal> ne;
    ne.setSearchMethod(tree);
    ne.setInputCloud(cloud);
    ne.setKSearch(50);
    ne.compute(*normals);

    // 3. RegionGrowing �ָ�
    pcl::RegionGrowing<pcl::PointXYZ, pcl::Normal> reg;
    reg.setMinClusterSize(50);
    reg.setMaxClusterSize(1000000);
    reg.setSearchMethod(tree);
    reg.setNumberOfNeighbours(30);
    reg.setInputCloud(cloud);
    reg.setInputNormals(normals);
    reg.setSmoothnessThreshold(3.0f / 180.0f * float(M_PI)); // 3��
    reg.setCurvatureThreshold(1.0f);

    std::vector<pcl::PointIndices> clusters;
    reg.extract(clusters);

    // 4. �ѽ��д�� result[]��Ĭ�� -1
    for (size_t i = 0; i < npoints; ++i) result[i] = -1;
    for (int clusterID = 0; clusterID < static_cast<int>(clusters.size()); ++clusterID) {
        const auto& indices = clusters[clusterID].indices;
        for (int idx : indices) result[idx] = clusterID;
    }

    return static_cast<int>(clusters.size());
}