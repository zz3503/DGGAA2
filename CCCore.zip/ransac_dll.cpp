#include "ransac_dll.h"

#include <vector>
#include <unordered_map>
#define _USE_MATH_DEFINES
#include <math.h>
#include <limits>
#include <exception>
#include <iostream>

#include <PlanePrimitiveShape.h>
#include <SpherePrimitiveShape.h>
#include <CylinderPrimitiveShape.h>

#include <PointCloud.h>
#include <RansacShapeDetector.h>
#include <PlanePrimitiveShapeConstructor.h>
#include <SpherePrimitiveShapeConstructor.h>
#include <CylinderPrimitiveShapeConstructor.h>

static const double SCALE = 1e9;

struct IPoint {
    int64_t x, y, z;
    bool operator==(const IPoint& o) const { return x == o.x && y == o.y && z == o.z; }
};

struct IPointHash {
    size_t operator()(const IPoint& p) const noexcept {
        size_t h1 = std::hash<long long>()(p.x);
        size_t h2 = std::hash<long long>()(p.y);
        size_t h3 = std::hash<long long>()(p.z);
        return h1 ^ (h2 << 1) ^ (h3 << 2);
    }
};

static inline IPoint to_ipoint(const Point& p)
{
    return IPoint{
        (int64_t)std::llround(p[0] * SCALE),
        (int64_t)std::llround(p[1] * SCALE),
        (int64_t)std::llround(p[2] * SCALE)
    };
}

extern "C"
RANSAC_API int RansacDetect(const double* points, size_t npoints, int* clusters)
{
    if (!points || !clusters || npoints == 0) return -1;

    try {
        // 1. �������
        PointCloud pc;
        pc.reserve(npoints);
        for (size_t i = 0; i < npoints; ++i) {
            pc.push_back(Point(Vec3f(
                points[3 * i + 0],
                points[3 * i + 1],
                points[3 * i + 2]
            )));
        }

        // 2. ӳ�乹��
        std::unordered_map<IPoint, int, IPointHash> mp;
        mp.reserve(npoints);

        Vec3f bmin(FLT_MAX, FLT_MAX, FLT_MAX);
        Vec3f bmax(-FLT_MAX, -FLT_MAX, -FLT_MAX);

        for (int i = 0; i < (int)pc.size(); ++i)
        {
            const Point& p = pc[i];
            if (p[0] < bmin[0]) bmin[0] = (float)p[0];
            if (p[1] < bmin[1]) bmin[1] = (float)p[1];
            if (p[2] < bmin[2]) bmin[2] = (float)p[2];
            if (p[0] > bmax[0]) bmax[0] = (float)p[0];
            if (p[1] > bmax[1]) bmax[1] = (float)p[1];
            if (p[2] > bmax[2]) bmax[2] = (float)p[2];

            mp[to_ipoint(p)] = i;
        }
        pc.setBBox(bmin, bmax);
        pc.calcNormals(3);

        // 3. Ĭ�� RANSAC ����
        RansacShapeDetector::Options opt;
        opt.m_epsilon = 0.005f * pc.getScale();
        opt.m_bitmapEpsilon = 0.01f * pc.getScale();
        opt.m_normalThresh = cosf(25.0f * 3.1415926f / 180.0f);
        opt.m_minSupport = 500;
        opt.m_probability = 0.01f;

        RansacShapeDetector detector(opt);
        detector.Add(new PlanePrimitiveShapeConstructor());
        detector.Add(new SpherePrimitiveShapeConstructor());
        detector.Add(new CylinderPrimitiveShapeConstructor());

        MiscLib::Vector< std::pair<MiscLib::RefCountPtr<PrimitiveShape>, size_t> > shapes;
        detector.Detect(pc, 0, pc.size(), &shapes);

        // 4. ���д�� clusters
        for (size_t i = 0; i < npoints; ++i) clusters[i] = -1;

        std::vector<int> mapping(pc.size());
        for (int i = 0; i < (int)pc.size(); ++i)
            mapping[mp[to_ipoint(pc[i])]] = i;

        int cnt = (int)pc.size();
        int cid = 0;
        std::vector<int> temp(pc.size(), -1);
        for (int s = 0; s < (int)shapes.size(); ++s)
        {
            for (size_t j = 0; j < shapes[s].second; ++j)
            {
                temp[--cnt] = cid;
            }
            cid++;
        }
        for (int i = 0; i < pc.size(); i++)
        {
            clusters[i] = temp[mapping[i]];
        }
        return 0;
    }
    catch (...) {
        return -99; // δ֪����
    }
}


extern "C"
RANSAC_API void RANSAC_PLANE(const double* points, const size_t npoints, float* result)
{
	Vec3f bboxMin(std::numeric_limits<float>::max(), std::numeric_limits<float>::max(), std::numeric_limits<float>::max());
	Vec3f bboxMax(-std::numeric_limits<float>::max(), -std::numeric_limits<float>::max(), -std::numeric_limits<float>::max());
	PointCloud cloud;
	{
		for (int i = 0; i < npoints; i++)
		{
			cloud.push_back(Point(Vec3f(points[i * 3 + 0], points[i * 3 + 1], points[i * 3 + 2])));
			if (cloud[i][0] < bboxMin[0]) bboxMin[0] = (float)cloud[i][0];
			if (cloud[i][1] < bboxMin[1]) bboxMin[1] = (float)cloud[i][1];
			if (cloud[i][2] < bboxMin[2]) bboxMin[2] = (float)cloud[i][2];
			if (cloud[i][0] > bboxMax[0]) bboxMax[0] = (float)cloud[i][0];
			if (cloud[i][1] > bboxMax[1]) bboxMax[1] = (float)cloud[i][1];
			if (cloud[i][2] > bboxMax[2]) bboxMax[2] = (float)cloud[i][2];
		}
	}
	cloud.setBBox(bboxMin, bboxMax);
	const float scale = cloud.getScale();
	cloud.calcNormals(.05f * scale);
	RansacShapeDetector::Options ransacOptions;
	{
		ransacOptions.m_epsilon = .005f * scale;
		ransacOptions.m_bitmapEpsilon = .05f * scale;
		ransacOptions.m_normalThresh = cos(25.0 / 180.0 * M_PI);
		ransacOptions.m_probability = .01f;
		ransacOptions.m_minSupport = std::min(500, (int)((float)npoints * 0.25));
	}
	RansacShapeDetector detector(ransacOptions);
	detector.Add(new PlanePrimitiveShapeConstructor());
	typedef std::pair< MiscLib::RefCountPtr< PrimitiveShape >, size_t > DetectedShape;
	MiscLib::Vector< DetectedShape > shapes;
	size_t remaining = detector.Detect(cloud, 0, cloud.size(), &shapes); // run detection
	MiscLib::Vector<DetectedShape>::const_iterator it = shapes.begin();
	const PrimitiveShape* shape = it->first;
	unsigned shapePointsCount = static_cast<unsigned>(it->second);
	const PlanePrimitiveShape* plane = static_cast<const PlanePrimitiveShape*>(shape);
	Vec3f G = plane->Internal().getPosition();
	Vec3f N = plane->Internal().getNormal();
	Vec3f X = plane->getXDim();
	Vec3f Y = plane->getYDim();
	float minX, maxX, minY, maxY;
	const auto shapeCloudIndex = cloud.size() - 1;
	for (unsigned j = 0; j < shapePointsCount; ++j)
	{
		std::pair<float, float> param;
		plane->Parameters(cloud[shapeCloudIndex - j].pos, &param);
		if (j != 0)
		{
			if (minX < param.first)
				minX = param.first;
			else if (maxX > param.first)
				maxX = param.first;
			if (minY < param.second)
				minY = param.second;
			else if (maxY > param.second)
				maxY = param.second;
		}
		else
		{
			minX = maxX = param.first;
			minY = maxY = param.second;
		}
	}
	result[0] = std::min(minX, maxX); // U_min
	result[1] = std::max(minX, maxX); // U_max
	result[2] = std::min(minY, maxY); // V_min
	result[3] = std::max(minY, maxY); // V_max
	result[4] = 0; // R
	result[5] = G[0]; // Location.x
	result[6] = G[1]; // Location.y
	result[7] = G[2]; // Location.z
	result[8] = X[0]; // XAxis.x
	result[9] = X[1]; // XAxis.y
	result[10] = X[2]; // XAxis.z
	result[11] = Y[0]; // YAxis.x
	result[12] = Y[1]; // YAxis.y
	result[13] = Y[2]; // YAxis.z
	result[14] = N[0]; // ZAxis.x
	result[15] = N[1]; // ZAxis.y
	result[16] = N[2]; // ZAxis.z
	// Geom_Plane P(u, v) = O + u * XDir + v * YDir
}

extern "C"
RANSAC_API void RANSAC_CYLINDER(const double* points, const size_t npoints, float* result)
{
	Vec3f bboxMin(std::numeric_limits<float>::max(), std::numeric_limits<float>::max(), std::numeric_limits<float>::max());
	Vec3f bboxMax(-std::numeric_limits<float>::max(), -std::numeric_limits<float>::max(), -std::numeric_limits<float>::max());
	PointCloud cloud;
	{
		for (int i = 0; i < npoints; i++)
		{
			cloud.push_back(Point(Vec3f(points[i * 3 + 0], points[i * 3 + 1], points[i * 3 + 2])));
			if (cloud[i][0] < bboxMin[0]) bboxMin[0] = (float)cloud[i][0];
			if (cloud[i][1] < bboxMin[1]) bboxMin[1] = (float)cloud[i][1];
			if (cloud[i][2] < bboxMin[2]) bboxMin[2] = (float)cloud[i][2];
			if (cloud[i][0] > bboxMax[0]) bboxMax[0] = (float)cloud[i][0];
			if (cloud[i][1] > bboxMax[1]) bboxMax[1] = (float)cloud[i][1];
			if (cloud[i][2] > bboxMax[2]) bboxMax[2] = (float)cloud[i][2];
		}
	}
	cloud.setBBox(bboxMin, bboxMax);
	const float scale = cloud.getScale();
	cloud.calcNormals(.05f * scale);
	RansacShapeDetector::Options ransacOptions;
	{
		ransacOptions.m_epsilon = .005f * scale;
		ransacOptions.m_bitmapEpsilon = .05f * scale;
		ransacOptions.m_normalThresh = cos(25.0 / 180.0 * M_PI);
		ransacOptions.m_probability = .01f;
		ransacOptions.m_minSupport = std::min(500, (int)((float)npoints * 0.25));
	}
	RansacShapeDetector detector(ransacOptions);
	detector.Add(new CylinderPrimitiveShapeConstructor());
	typedef std::pair< MiscLib::RefCountPtr< PrimitiveShape >, size_t > DetectedShape;
	MiscLib::Vector< DetectedShape > shapes;
	size_t remaining = detector.Detect(cloud, 0, cloud.size(), &shapes); // run detection
	MiscLib::Vector<DetectedShape>::const_iterator it = shapes.begin();
	const PrimitiveShape* shape = it->first;
	unsigned shapePointsCount = static_cast<unsigned>(it->second);
	const CylinderPrimitiveShape* cyl = static_cast<const CylinderPrimitiveShape*>(shape);
	Vec3f G = cyl->Internal().AxisPosition();
	Vec3f N = cyl->Internal().AxisDirection();
	Vec3f X = cyl->Internal().AngularDirection();
	Vec3f Y = N.cross(X);
	float r = cyl->Internal().Radius();
	float hMin = cyl->MinHeight();
	float hMax = cyl->MaxHeight();
	float h = hMax - hMin;
	float minX, maxX, minY, maxY;
	const auto shapeCloudIndex = cloud.size() - 1;
	for (unsigned j = 0; j < shapePointsCount; ++j)
	{
		std::pair<float, float> param;
		cyl->Parameters(cloud[shapeCloudIndex - j].pos, &param);
		if (j != 0)
		{
			if (minX < param.first)
				minX = param.first;
			else if (maxX > param.first)
				maxX = param.first;
			if (minY < param.second)
				minY = param.second;
			else if (maxY > param.second)
				maxY = param.second;
		}
		else
		{
			minX = maxX = param.first;
			minY = maxY = param.second;
		}
	}
	
	result[0] = std::min(minY / r, maxY / r); // U_min
	result[1] = std::max(minY / r, maxY / r); // U_max
	result[2] = std::min(minX, maxX); // V_min
	result[3] = std::max(minX, maxX); // V_max
	result[4] = r; // R
	result[5] = G[0]; // Location.x
	result[6] = G[1]; // Location.y
	result[7] = G[2]; // Location.z
	result[8] = X[0]; // XAxis.x
	result[9] = X[1]; // XAxis.y
	result[10] = X[2]; // XAxis.z
	result[11] = Y[0]; // YAxis.x
	result[12] = Y[1]; // YAxis.y
	result[13] = Y[2]; // YAxis.z
	result[14] = N[0]; // ZAxis.x
	result[15] = N[1]; // ZAxis.y
	result[16] = N[2]; // ZAxis.z
	// Geom_CylindricalSurface P(U, V) = Location + R * cos(U) * XAxis + R * sin(U) * YAxis + V * ZAxis
}

extern "C"
RANSAC_API void RANSAC_SPHERE(const double* points, const size_t npoints, float* result)
{
	Vec3f bboxMin(std::numeric_limits<float>::max(), std::numeric_limits<float>::max(), std::numeric_limits<float>::max());
	Vec3f bboxMax(-std::numeric_limits<float>::max(), -std::numeric_limits<float>::max(), -std::numeric_limits<float>::max());
	PointCloud cloud;
	{
		for (int i = 0; i < npoints; i++)
		{
			cloud.push_back(Point(Vec3f(points[i * 3 + 0], points[i * 3 + 1], points[i * 3 + 2])));
			if (cloud[i][0] < bboxMin[0]) bboxMin[0] = (float)cloud[i][0];
			if (cloud[i][1] < bboxMin[1]) bboxMin[1] = (float)cloud[i][1];
			if (cloud[i][2] < bboxMin[2]) bboxMin[2] = (float)cloud[i][2];
			if (cloud[i][0] > bboxMax[0]) bboxMax[0] = (float)cloud[i][0];
			if (cloud[i][1] > bboxMax[1]) bboxMax[1] = (float)cloud[i][1];
			if (cloud[i][2] > bboxMax[2]) bboxMax[2] = (float)cloud[i][2];
		}
	}
	cloud.setBBox(bboxMin, bboxMax);
	const float scale = cloud.getScale();
	cloud.calcNormals(.05f * scale);
	RansacShapeDetector::Options ransacOptions;
	{
		ransacOptions.m_epsilon = .005f * scale;
		ransacOptions.m_bitmapEpsilon = .05f * scale;
		ransacOptions.m_normalThresh = cos(25.0 / 180.0 * M_PI);
		ransacOptions.m_probability = .01f;
		ransacOptions.m_minSupport = std::min(500, (int)((float)npoints * 0.25));
	}
	RansacShapeDetector detector(ransacOptions);
	detector.Add(new SpherePrimitiveShapeConstructor());
	typedef std::pair< MiscLib::RefCountPtr< PrimitiveShape >, size_t > DetectedShape;
	MiscLib::Vector< DetectedShape > shapes;
	size_t remaining = detector.Detect(cloud, 0, cloud.size(), &shapes); // run detection
	MiscLib::Vector<DetectedShape>::const_iterator it = shapes.begin();
	const PrimitiveShape* shape = it->first;
	unsigned shapePointsCount = static_cast<unsigned>(it->second);
	const SpherePrimitiveShape* sphere = static_cast<const SpherePrimitiveShape*>(shape);
	float radius = sphere->Internal().Radius();
	Vec3f CC = sphere->Internal().Center();
	float minX, maxX, minY, maxY;
	const auto shapeCloudIndex = cloud.size() - 1;
	for (unsigned j = 0; j < shapePointsCount; ++j)
	{
		std::pair<float, float> param;
		sphere->Parameters(cloud[shapeCloudIndex - j].pos, &param);
		if (j != 0)
		{
			if (minX < param.first)
				minX = param.first;
			else if (maxX > param.first)
				maxX = param.first;
			if (minY < param.second)
				minY = param.second;
			else if (maxY > param.second)
				maxY = param.second;
		}
		else
		{
			minX = maxX = param.first;
			minY = maxY = param.second;
		}
	}

	result[0] = std::min(minX, maxX); // U_min
	result[1] = std::max(minX, maxX); // U_max
	result[2] = std::min(minY, maxY); // V_min
	result[3] = std::max(minY, maxY); // V_max
	result[4] = radius; // R
	result[5] = CC[0]; // Location.x
	result[6] = CC[1]; // Location.y
	result[7] = CC[2]; // Location.z
	result[8] = sphere->m_parametrization.m_frame[0][0]; // XAxis.x
	result[9] = sphere->m_parametrization.m_frame[0][1]; // XAxis.y
	result[10] = sphere->m_parametrization.m_frame[0][2]; // XAxis.z
	result[11] = sphere->m_parametrization.m_frame[1][0]; // YAxis.x
	result[12] = sphere->m_parametrization.m_frame[1][1]; // YAxis.y
	result[13] = sphere->m_parametrization.m_frame[1][2]; // YAxis.z
	result[14] = sphere->m_parametrization.m_frame[2][0]; // ZAxis.x
	result[15] = sphere->m_parametrization.m_frame[2][1]; // ZAxis.y
	result[16] = sphere->m_parametrization.m_frame[2][2]; // ZAxis.z
	// Geom_SphericalSurface P(U, V) = Loc + Radius * Sin(V) * Zdir + Radius * Cos(V) * (cos(U) * XDir + sin(U) * YDir) 
}

