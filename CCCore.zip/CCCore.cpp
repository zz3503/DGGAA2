﻿#include <PointCloud.h>
#include <RansacShapeDetector.h>
#include <PlanePrimitiveShapeConstructor.h>
#include <CylinderPrimitiveShapeConstructor.h>
#include <SpherePrimitiveShapeConstructor.h>
#include <ConePrimitiveShapeConstructor.h>
#include <TorusPrimitiveShapeConstructor.h>

#include <PlanePrimitiveShape.h>
#include <SpherePrimitiveShape.h>
#include <CylinderPrimitiveShape.h>
#include <CONEPrimitiveShape.h>

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include <unordered_map>


static const double SCALE = 1e9;

struct IPoint {
	int64_t x, y, z;
	bool operator==(const IPoint& o) const {
		return x == o.x && y == o.y && z == o.z;
	}
};

struct IPointHash {
	size_t operator()(const IPoint& p) const noexcept {
		size_t h1 = std::hash<int64_t>()(p.x);
		size_t h2 = std::hash<int64_t>()(p.y);
		size_t h3 = std::hash<int64_t>()(p.z);
		return h1 ^ (h2 << 1) ^ (h3 << 2);
	}
};

IPoint to_ipoint(const Point& p) {
	return IPoint{
		int64_t(std::llround(p[0] * SCALE)),
		int64_t(std::llround(p[1] * SCALE)),
		int64_t(std::llround(p[2] * SCALE))
	};
}

void RANSAC(PointCloud& pc, std::vector<int>& cluster)
{
	std::unordered_map<IPoint, int, IPointHash> mp;
	mp.reserve(pc.size());
	Vec3f bboxMin(std::numeric_limits<float>::max(), std::numeric_limits<float>::max(), std::numeric_limits<float>::max());
	Vec3f bboxMax(-std::numeric_limits<float>::max(), -std::numeric_limits<float>::max(), -std::numeric_limits<float>::max());
	for (int i = 0; i < pc.size(); i++)
	{
		if (pc[i][0] < bboxMin[0]) bboxMin[0] = (float)pc[i][0];
		if (pc[i][1] < bboxMin[1]) bboxMin[1] = (float)pc[i][1];
		if (pc[i][2] < bboxMin[2]) bboxMin[2] = (float)pc[i][2];
		if (pc[i][0] > bboxMax[0]) bboxMax[0] = (float)pc[i][0];
		if (pc[i][1] > bboxMax[1]) bboxMax[1] = (float)pc[i][1];
		if (pc[i][2] > bboxMax[2]) bboxMax[2] = (float)pc[i][2];
		mp[to_ipoint(pc[i])] = i;
	}
	pc.setBBox(bboxMin, bboxMax);
	pc.calcNormals(3);
	RansacShapeDetector::Options ransacOptions;
	ransacOptions.m_epsilon = .005f * pc.getScale(); // set distance threshold to .01f of bounding box width
	// NOTE: Internally the distance threshold is taken as 3 * ransacOptions.m_epsilon!!!
	ransacOptions.m_bitmapEpsilon = .01f * pc.getScale(); // set bitmap resolution to .02f of bounding box width
	// NOTE: This threshold is NOT multiplied internally!
	ransacOptions.m_normalThresh = cos(25.0 / 180.0 * M_PI); // this is the cos of the maximal normal deviation
	ransacOptions.m_minSupport = 500; // this is the minimal numer of points required for a primitive
	ransacOptions.m_probability = .01f; // this is the "probability" with which a primitive is overlooked
	RansacShapeDetector detector(ransacOptions);
	detector.Add(new PlanePrimitiveShapeConstructor());
	detector.Add(new SpherePrimitiveShapeConstructor());
	detector.Add(new CylinderPrimitiveShapeConstructor());
	MiscLib::Vector< std::pair< MiscLib::RefCountPtr< PrimitiveShape >, size_t > > shapes; // stores the detected shapes
	size_t remaining = detector.Detect(pc, 0, pc.size(), &shapes); // run detection
	std::vector<int> mapping(pc.size());
	for (int i = 0; i < pc.size(); ++i)
	{
		mapping[mp[to_ipoint(pc[i])]] = i;
	}
	int m_cluster = 0;
	int cnt = pc.size();
	std::vector<int> temp(pc.size(), -1);
	for (int i = 0; i < shapes.size(); i++)
	{
		for (int j = 0; j < shapes[i].second; j++)
		{
			temp[--cnt] = m_cluster;
		}
		m_cluster++;
	}
	for (int i = 0; i < pc.size(); i++)
	{
		cluster[i] = temp[mapping[i]];
	}
}


void RANSAC_CONE(const double* points, const size_t npoints)
{
	Vec3f bboxMin(std::numeric_limits<float>::max(), std::numeric_limits<float>::max(), std::numeric_limits<float>::max());
	Vec3f bboxMax(-std::numeric_limits<float>::max(), -std::numeric_limits<float>::max(), -std::numeric_limits<float>::max());
	PointCloud cloud;
	{
		for (int i = 0; i < npoints; i++)
		{
			cloud.push_back(Point(Vec3f(points[i * 3 + 0], points[i * 3 + 1], points[i * 3 + 2])));
			if (cloud[i][0] < bboxMin[0]) bboxMin[0] = (float)cloud[i][0];
			if (cloud[i][1] < bboxMin[1]) bboxMin[1] = (float)cloud[i][1];
			if (cloud[i][2] < bboxMin[2]) bboxMin[2] = (float)cloud[i][2];
			if (cloud[i][0] > bboxMax[0]) bboxMax[0] = (float)cloud[i][0];
			if (cloud[i][1] > bboxMax[1]) bboxMax[1] = (float)cloud[i][1];
			if (cloud[i][2] > bboxMax[2]) bboxMax[2] = (float)cloud[i][2];
		}
	}
	cloud.setBBox(bboxMin, bboxMax);
	const float scale = cloud.getScale();
	cloud.calcNormals(.01f * scale);
	RansacShapeDetector::Options ransacOptions;
	{
		ransacOptions.m_epsilon = .005f * scale;
		ransacOptions.m_bitmapEpsilon = .01f * scale;
		ransacOptions.m_normalThresh = cos(25.0 / 180.0 * M_PI);
		ransacOptions.m_probability = .01f;
		ransacOptions.m_minSupport = 500;
	}
	RansacShapeDetector detector(ransacOptions);
	detector.Add(new ConePrimitiveShapeConstructor());
	typedef std::pair< MiscLib::RefCountPtr< PrimitiveShape >, size_t > DetectedShape;
	MiscLib::Vector< DetectedShape > shapes;
	size_t remaining = detector.Detect(cloud, 0, cloud.size(), &shapes); // run detection
	MiscLib::Vector<DetectedShape>::const_iterator it = shapes.begin();
	const PrimitiveShape* shape = it->first;
	unsigned shapePointsCount = static_cast<unsigned>(it->second);
	const ConePrimitiveShape* cone = static_cast<const ConePrimitiveShape*>(shape);
	Vec3f CC = cone->Internal().Center();
	Vec3f Z = cone->Internal().AxisDirection();
	Vec3f X = cone->Internal().AngularDirection();
	Vec3f Y = Z.cross(X);
	float alpha_rad = cone->Internal().Angle();

	float minX, maxX, minY, maxY;
	const auto shapeCloudIndex = cloud.size() - 1;
	for (unsigned j = 0; j < shapePointsCount; ++j)
	{
		std::pair<float, float> param;
		cone->Parameters(cloud[shapeCloudIndex - j].pos, &param);
		if (j != 0)
		{
			if (minX < param.first)
				minX = param.first;
			else if (maxX > param.first)
				maxX = param.first;
			if (minY < param.second)
				minY = param.second;
			else if (maxY > param.second)
				maxY = param.second;
		}
		else
		{
			minX = maxX = param.first;
			minY = maxY = param.second;
		}
	}
	
	std::cout << alpha_rad << std::endl;
	std::cout << CC[0] << " " << CC[1] << " " << CC[2] << std::endl;
	std::cout << minX << " " << maxX << std::endl;
	std::cout << minY << " " << maxY << std::endl;
	for (unsigned j = 0; j < shapePointsCount; ++j)
	{
		std::pair<float, float> param;
		cone->Parameters(cloud[shapeCloudIndex - j].pos, &param);
		auto p_min = cloud[shapeCloudIndex - j].pos;
		auto V = param.second;
		auto U = param.first;
		// O + (R + v * sin(Ang)) * (cos(u) * XDir + sin(u) * YDir) + v * cos(Ang) * ZDir

		//std::cout << p_min[0] << " " << p_min[1] << " " << p_min[2] << std::endl;
		//std::cout << U << " " << V << std::endl;
		//std::cout << p_max[0] << " " << p_max[1] << " " << p_max[2] << std::endl;

		if (j != 0)
		{
			if (minX < param.first)
				minX = param.first;
			else if (maxX > param.first)
				maxX = param.first;
			if (minY < param.second)
				minY = param.second;
			else if (maxY > param.second)
				maxY = param.second;
		}
		else
		{
			minX = maxX = param.first;
			minY = maxY = param.second;
		}
		if (j != 0)
			break;
	}
}

int main()
{
	PointCloud pc;
	PointCloud newpc;
	//std::ifstream infile("E:\\data\\stp\\output\\easy\\2.txt");
	std::ifstream infile("C:\\Users\\WRW\\Desktop\\1\\Sphere_0002.txt");

	if (!infile.is_open()) {
		std::cerr << "无法打开文件!" << std::endl;
		return -1;
	}
	std::string line;
	while (std::getline(infile, line)) {
		std::istringstream iss(line);
		//double x, y, z, rx, ry, rz, l;
		//if (!(iss >> x >> y >> z >> rx >> ry >> rz >> l)) {
		//	std::cerr << "Warning: 跳过格式错误行: " << line << std::endl;
		//	continue;
		//}
		double x, y, z, rx, ry, rz, r, g, b, l;
		if (!(iss >> x >> y >> z >> rx >> ry >> rz >>r >> g >> b >> l)) {
			std::cerr << "Warning: 跳过格式错误行: " << line << std::endl;
			continue;
		}
		pc.push_back(Point(Vec3f(x, y, z)));
		// newpc.push_back(Point(Vec3f(x, y, z)));
	}
	infile.close();
	int size = pc.size();
	double* data = new double[size * 3];
	for (int i = 0; i < size; i++)
	{
		data[i * 3 + 0] = pc[i].pos[0];
		data[i * 3 + 1] = pc[i].pos[1];
		data[i * 3 + 2] = pc[i].pos[2];
	}
	RANSAC_CONE(data, size);
	//std::vector<int> cluster(pc.size(), -1);
	//RANSAC(pc, cluster);

	//std::ofstream _outfile("C:\\Users\\WRW\\Desktop\\easy_2.txt");
	//if (!_outfile.is_open()) {
	//	std::cerr << "无法打开输出文件!" << std::endl;
	//	return -1;
	//}
	//for (int i = 0; i < newpc.size(); i++)
	//{
	//	_outfile << newpc[i][0] << " " << newpc[i][1] << " " << newpc[i][2] << " " << cluster[i] << "\n";
	//}

}
